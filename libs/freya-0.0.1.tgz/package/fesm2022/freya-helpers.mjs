import { firstValueFrom, timer } from 'rxjs';
import { map } from 'rxjs/operators';

const wait = (ms) => firstValueFrom(timer(ms).pipe(map(() => undefined)));
const getRequestAsync = async (request) => {
    try {
        const data = await firstValueFrom(request);
        return { status: true, data };
    }
    catch (error) {
        return { status: false, error };
    }
};

const isNullOrUndefined = (data) => {
    return data === null || data === undefined ? true : false || data === '';
};
const isDefined = (data) => {
    return data !== null && data !== undefined;
};

const isObjectEmpty = (obj) => {
    if (obj === null || obj === undefined) {
        return true;
    }
    return Object.values(obj).every((value) => {
        if (typeof value === 'object') {
            return isObjectEmpty(value);
        }
        return value === null;
    });
};
const getObjectNestedProperty = (obj, path) => path.split('.').reduce((acc, key) => acc && acc[key], obj);

/**
 * Generated bundle index. Do not edit.
 */

export { getObjectNestedProperty, getRequestAsync, isDefined, isNullOrUndefined, isObjectEmpty, wait };
//# sourceMappingURL=freya-helpers.mjs.map
