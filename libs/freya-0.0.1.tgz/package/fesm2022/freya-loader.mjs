import * as i0 from '@angular/core';
import { signal, Injectable, inject } from '@angular/core';
import { finalize } from 'rxjs';

class FreyLoaderService {
    statusLoader = signal(false, ...(ngDevMode ? [{ debugName: "statusLoader" }] : []));
    loaderChange(statusLoader) {
        this.statusLoader.set(statusLoader);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyLoaderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyLoaderService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyLoaderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

let requestCounter = 0;
const FreyLoaderInterceptor = (req, next) => {
    const loaderService = inject(FreyLoaderService);
    if (!requestCounter) {
        loaderService.loaderChange(true);
    }
    requestCounter++;
    return next(req).pipe(finalize(() => {
        requestCounter--;
        if (!requestCounter) {
            loaderService.loaderChange(false);
        }
    }));
};

/**
 * Generated bundle index. Do not edit.
 */

export { FreyLoaderInterceptor, FreyLoaderService };
//# sourceMappingURL=freya-loader.mjs.map
