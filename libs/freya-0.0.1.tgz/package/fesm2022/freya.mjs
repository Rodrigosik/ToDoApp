/**
 * Versión de Freya UI Library
 */
const FREYA_VERSION = '0.0.1';

/**
 * Generated bundle index. Do not edit.
 */

export { FREYA_VERSION };
//# sourceMappingURL=freya.mjs.map
