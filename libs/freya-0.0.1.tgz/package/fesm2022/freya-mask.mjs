import * as i0 from '@angular/core';
import { inject, ElementRef, forwardRef, HostListener, Input, Directive } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

class FreyMaskDirective {
    customMask = '';
    allowedCharacters = /[^0-9a-zA-Z]/g;
    elementRef = inject(ElementRef);
    writeValue(value) {
        if (value !== null && value !== undefined) {
            this.elementRef.nativeElement.value = value;
            this.applyMaskToCurrentValue();
        }
        else {
            this.elementRef.nativeElement.value = '';
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.elementRef.nativeElement.disabled = isDisabled;
    }
    onInput() {
        const input = this.elementRef.nativeElement;
        const cleanedValue = input.value.replace(this.allowedCharacters, '');
        const maskedValue = this.applyMask(cleanedValue);
        const controlValue = this.buildControlValue(maskedValue, cleanedValue);
        input.value = maskedValue;
        this.onChange(controlValue);
    }
    onBlur() {
        this.onTouched();
    }
    applyMaskToCurrentValue() {
        const input = this.elementRef.nativeElement;
        const cleanedValue = input.value.replace(this.allowedCharacters, '');
        const maskedValue = this.applyMask(cleanedValue);
        input.value = maskedValue;
    }
    applyMask(cleanedValue) {
        let maskedValue = '';
        let valueIndex = 0;
        const characterMatchers = {
            '9': /^\d$/,
            A: /^[a-zA-Z]$/,
            B: /^[0-9a-zA-Z]$/,
        };
        for (const char of this.customMask) {
            if (valueIndex >= cleanedValue.length) {
                break;
            }
            const matcher = characterMatchers[char];
            const currentChar = cleanedValue.charAt(valueIndex);
            if (matcher && matcher.test(currentChar)) {
                maskedValue += currentChar;
                valueIndex++;
            }
            else if (!matcher) {
                maskedValue += char;
            }
            else if (matcher && !matcher.test(currentChar)) {
                valueIndex++;
            }
        }
        return maskedValue;
    }
    buildControlValue(maskedValue, cleanedValue) {
        const textMask = this.customMask.replace(this.allowedCharacters, '');
        const textInput = maskedValue.replace(this.allowedCharacters, '');
        let controlValue = cleanedValue;
        if (textInput.length > textMask.length) {
            controlValue = controlValue.slice(0, textMask.length);
        }
        else {
            controlValue = controlValue.slice(0, textInput.length);
        }
        return controlValue;
    }
    onChange = () => { };
    onTouched = () => { };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyMaskDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyMaskDirective, isStandalone: true, selector: "[freyMask]", inputs: { customMask: ["freyMask", "customMask"] }, host: { listeners: { "input": "onInput()", "blur": "onBlur()" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FreyMaskDirective),
                multi: true,
            },
        ], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyMaskDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyMask]',
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FreyMaskDirective),
                            multi: true,
                        },
                    ],
                }]
        }], propDecorators: { customMask: [{
                type: Input,
                args: ['freyMask']
            }], onInput: [{
                type: HostListener,
                args: ['input', []]
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyMaskDirective };
//# sourceMappingURL=freya-mask.mjs.map
