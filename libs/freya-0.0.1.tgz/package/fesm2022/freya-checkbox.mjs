import { NgClass } from '@angular/common';
import * as i0 from '@angular/core';
import { EventEmitter, viewChild, computed, signal, forwardRef, Output, Input, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';

class FreyCheckboxComponent {
    disabled = false;
    readonly = false;
    value = false;
    changeSelection = new EventEmitter();
    labelContent$$ = viewChild('labelContent', ...(ngDevMode ? [{ debugName: "labelContent$$" }] : []));
    hasLabelContent$$ = computed(() => this.labelContent$$().nativeElement?.innerHTML.trim().length > 0, ...(ngDevMode ? [{ debugName: "hasLabelContent$$" }] : []));
    iconContent$$ = viewChild('icon', ...(ngDevMode ? [{ debugName: "iconContent$$" }] : []));
    hasIconContent$$ = computed(() => this.iconContent$$().nativeElement?.innerHTML.trim().length > 0, ...(ngDevMode ? [{ debugName: "hasIconContent$$" }] : []));
    checked$$ = signal(false, ...(ngDevMode ? [{ debugName: "checked$$" }] : []));
    onChange = () => { };
    onTouched = () => { };
    ngOnChanges() {
        this.checked$$.set(this.value);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    writeValue(value) {
        this.checked$$.set(value);
    }
    onModelChange(value) {
        if (this.disabled) {
            return;
        }
        this.checked$$.set(value);
        this.onChange(value);
        this.changeSelection.emit(value);
    }
    setDisabledState(disabled) {
        this.disabled = disabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: FreyCheckboxComponent, isStandalone: true, selector: "frey-checkbox", inputs: { disabled: "disabled", readonly: "readonly", value: "value" }, outputs: { changeSelection: "changeSelection" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FreyCheckboxComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "labelContent$$", first: true, predicate: ["labelContent"], descendants: true, isSignal: true }, { propertyName: "iconContent$$", first: true, predicate: ["icon"], descendants: true, isSignal: true }], usesOnChanges: true, ngImport: i0, template: "<label\n  class=\"frey-checkbox\"\n  [ngClass]=\"{ 'frey-checkbox--disabled': disabled, 'frey-checkbox--no-gap': !hasLabelContent$$() }\"\n>\n  <input\n    type=\"checkbox\"\n    [ngModel]=\"checked$$()\"\n    (ngModelChange)=\"onModelChange($event)\"\n    class=\"frey-checkbox__input\"\n    [disabled]=\"disabled || readonly\"\n  />\n\n  <div class=\"frey-checkbox__figure\" [ngClass]=\"{ 'frey-checkbox__figure--checked': checked$$() }\">\n    @if (checked$$()) {\n      <div class=\"frey-checkbox__icon-container\">\n        <span #icon style=\"display: contents\" class=\"frey-checkbox__icon\">\n          <ng-content select=\"[icon]\"></ng-content>\n        </span>\n        @if (!hasIconContent$$()) {\n          <svg\n            xmlns=\"http://www.w3.org/2000/svg\"\n            viewBox=\"0 0 24 24\"\n            fill=\"none\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n            class=\"frey-checkbox__icon\"\n          >\n            <path d=\"M20 6 9 17l-5-5\" />\n          </svg>\n        }\n      </div>\n    }\n  </div>\n\n  <span #labelContent class=\"frey-checkbox__label\"><ng-content></ng-content></span>\n</label>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-checkbox', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FreyCheckboxComponent),
                            multi: true,
                        },
                    ], imports: [FormsModule, NgClass], template: "<label\n  class=\"frey-checkbox\"\n  [ngClass]=\"{ 'frey-checkbox--disabled': disabled, 'frey-checkbox--no-gap': !hasLabelContent$$() }\"\n>\n  <input\n    type=\"checkbox\"\n    [ngModel]=\"checked$$()\"\n    (ngModelChange)=\"onModelChange($event)\"\n    class=\"frey-checkbox__input\"\n    [disabled]=\"disabled || readonly\"\n  />\n\n  <div class=\"frey-checkbox__figure\" [ngClass]=\"{ 'frey-checkbox__figure--checked': checked$$() }\">\n    @if (checked$$()) {\n      <div class=\"frey-checkbox__icon-container\">\n        <span #icon style=\"display: contents\" class=\"frey-checkbox__icon\">\n          <ng-content select=\"[icon]\"></ng-content>\n        </span>\n        @if (!hasIconContent$$()) {\n          <svg\n            xmlns=\"http://www.w3.org/2000/svg\"\n            viewBox=\"0 0 24 24\"\n            fill=\"none\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n            class=\"frey-checkbox__icon\"\n          >\n            <path d=\"M20 6 9 17l-5-5\" />\n          </svg>\n        }\n      </div>\n    }\n  </div>\n\n  <span #labelContent class=\"frey-checkbox__label\"><ng-content></ng-content></span>\n</label>\n" }]
        }], propDecorators: { disabled: [{
                type: Input
            }], readonly: [{
                type: Input
            }], value: [{
                type: Input
            }], changeSelection: [{
                type: Output
            }], labelContent$$: [{ type: i0.ViewChild, args: ['labelContent', { isSignal: true }] }], iconContent$$: [{ type: i0.ViewChild, args: ['icon', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyCheckboxComponent };
//# sourceMappingURL=freya-checkbox.mjs.map
