import * as i0 from '@angular/core';
import { input, output, signal, computed, effect, forwardRef, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { FreyControlValueAccessor } from 'freya/class';

class FreyTimepickerComponent extends FreyControlValueAccessor {
    initialTime = input(null, ...(ngDevMode ? [{ debugName: "initialTime" }] : []));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : []));
    minTime = input(null, ...(ngDevMode ? [{ debugName: "minTime" }] : []));
    maxTime = input(null, ...(ngDevMode ? [{ debugName: "maxTime" }] : []));
    timeChange = output();
    hour = signal('12', ...(ngDevMode ? [{ debugName: "hour" }] : []));
    minute = signal('00', ...(ngDevMode ? [{ debugName: "minute" }] : []));
    period = signal('AM', ...(ngDevMode ? [{ debugName: "period" }] : []));
    formControlDisabled = signal(false, ...(ngDevMode ? [{ debugName: "formControlDisabled" }] : []));
    isInteractionDisabled = computed(() => this.disabled() || this.readonly() || this.formControlDisabled(), ...(ngDevMode ? [{ debugName: "isInteractionDisabled" }] : []));
    isInputDisabled = computed(() => this.disabled() || this.formControlDisabled(), ...(ngDevMode ? [{ debugName: "isInputDisabled" }] : []));
    currentTime = computed(() => {
        const hourNum = parseInt(this.hour()) || 12;
        const minuteNum = parseInt(this.minute()) || 0;
        const hour24 = this.convertTo24Hour(hourNum, this.period());
        return `${hour24.toString().padStart(2, '0')}:${minuteNum.toString().padStart(2, '0')}:00`;
    }, ...(ngDevMode ? [{ debugName: "currentTime" }] : []));
    constructor() {
        super();
        effect(() => {
            const min = this.minTime();
            if (min && this.hour() === '12' && this.minute() === '00' && this.period() === 'AM') {
                this.setTimeFromString(min);
            }
        });
        effect(() => {
            const currentTime = this.currentTime();
            this.timeChange.emit(currentTime);
            this.onChange(currentTime);
        });
    }
    writeValue(value) {
        if (value) {
            this.setTimeFromString(value);
        }
        else {
            this.resetToDefault();
        }
    }
    setDisabledState(isDisabled) {
        this.formControlDisabled.set(isDisabled);
    }
    onHourInput(event) {
        if (this.isInteractionDisabled()) {
            return;
        }
        const inputElement = event.target;
        const inputValue = inputElement.value;
        if (inputValue === '00') {
            inputElement.value = this.hour();
            return;
        }
        const value = this.sanitizeAndValidateHour(inputValue);
        this.hour.set(value);
        this.onTouched();
    }
    onMinuteInput(event) {
        if (this.isInteractionDisabled()) {
            return;
        }
        const value = this.sanitizeAndValidateMinute(event.target.value);
        this.minute.set(value);
        this.onTouched();
    }
    onHourBlur() {
        if (this.isInteractionDisabled()) {
            return;
        }
        const formattedHour = this.formatHour(this.hour());
        this.hour.set(formattedHour);
        this.validateTimeRange();
    }
    onMinuteBlur() {
        if (this.isInteractionDisabled()) {
            return;
        }
        const formattedMinute = this.formatMinute(this.minute());
        this.minute.set(formattedMinute);
        this.validateTimeRange();
    }
    togglePeriod() {
        if (this.isInteractionDisabled()) {
            return;
        }
        this.period.set(this.period() === 'AM' ? 'PM' : 'AM');
        this.onTouched();
        this.validateTimeRange();
    }
    validateTimeRange() {
        const currentTimeMinutes = this.getTimeInMinutes();
        if (this.minTime()) {
            const minMinutes = this.getTimeInMinutesFromString(this.minTime());
            if (currentTimeMinutes < minMinutes) {
                this.setTimeFromString(this.minTime());
                return;
            }
        }
        if (this.maxTime()) {
            const maxMinutes = this.getTimeInMinutesFromString(this.maxTime());
            if (currentTimeMinutes > maxMinutes) {
                this.setTimeFromString(this.maxTime());
                return;
            }
        }
    }
    getTimeInMinutes(date) {
        if (date) {
            return date.getHours() * 60 + date.getMinutes();
        }
        const currentHour = parseInt(this.hour()) || 12;
        const currentMinute = parseInt(this.minute()) || 0;
        const hour24 = this.convertTo24Hour(currentHour, this.period());
        return hour24 * 60 + currentMinute;
    }
    getTimeInMinutesFromString(timeString) {
        const timeParts = timeString.split(':');
        const hour = parseInt(timeParts[0]) || 0;
        const minute = parseInt(timeParts[1]) || 0;
        return hour * 60 + minute;
    }
    sanitizeAndValidateHour(input) {
        const cleaned = input.replace(/\D/g, '').substring(0, 2);
        if (!cleaned) {
            return this.hour();
        }
        const num = parseInt(cleaned);
        if (num === 0) {
            return this.hour();
        }
        if (cleaned.length === 1 && num > 1) {
            return num.toString().padStart(2, '0');
        }
        if (num > 12) {
            return cleaned.charAt(0);
        }
        return cleaned;
    }
    sanitizeAndValidateMinute(input) {
        const cleaned = input.replace(/\D/g, '').substring(0, 2);
        if (!cleaned) {
            return this.minute();
        }
        const num = parseInt(cleaned);
        if (cleaned.length === 1 && num > 5) {
            return num.toString().padStart(2, '0');
        }
        // Durante la entrada, permitir valores hasta 99 y que la validación real se haga en blur
        return cleaned;
    }
    formatHour(value) {
        const cleaned = value.replace(/\D/g, '');
        if (!cleaned) {
            return '12';
        }
        const num = parseInt(cleaned);
        if (num === 0 || num > 12) {
            return '12';
        }
        if (num < 1) {
            return '01';
        }
        return num.toString().padStart(2, '0');
    }
    formatMinute(value) {
        const cleaned = value.replace(/\D/g, '');
        if (!cleaned) {
            return '00';
        }
        const num = parseInt(cleaned);
        if (num > 59) {
            const firstDigit = parseInt(cleaned.charAt(0));
            if (firstDigit > 5) {
                return '00';
            }
            return firstDigit.toString().padStart(2, '0');
        }
        return num.toString().padStart(2, '0');
    }
    convertTo24Hour(hour12, period) {
        if (period === 'PM' && hour12 !== 12) {
            return hour12 + 12;
        }
        if (period === 'AM' && hour12 === 12) {
            return 0;
        }
        return hour12;
    }
    setTimeFromString(timeString) {
        const timeParts = timeString.split(':');
        const hour24 = parseInt(timeParts[0]) || 0;
        const minutes = parseInt(timeParts[1]) || 0;
        const hour12 = hour24 === 0 ? 12 : hour24 > 12 ? hour24 - 12 : hour24;
        const period = hour24 >= 12 ? 'PM' : 'AM';
        this.hour.set(hour12.toString().padStart(2, '0'));
        this.minute.set(minutes.toString().padStart(2, '0'));
        this.period.set(period);
    }
    resetToDefault() {
        this.hour.set('12');
        this.minute.set('00');
        this.period.set('AM');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTimepickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.1.2", type: FreyTimepickerComponent, isStandalone: true, selector: "frey-timepicker", inputs: { initialTime: { classPropertyName: "initialTime", publicName: "initialTime", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, minTime: { classPropertyName: "minTime", publicName: "minTime", isSignal: true, isRequired: false, transformFunction: null }, maxTime: { classPropertyName: "maxTime", publicName: "maxTime", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { timeChange: "timeChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FreyTimepickerComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<ng-content select=\"frey-label\"></ng-content>\n<div\n  class=\"time-picker\"\n  [class.time-picker--disabled]=\"isInputDisabled()\"\n  [class.time-picker--readonly]=\"readonly()\"\n>\n  <div class=\"time-picker__input-group\">\n    <input\n      class=\"time-picker__input\"\n      type=\"text\"\n      [value]=\"hour()\"\n      [disabled]=\"isInputDisabled()\"\n      [readonly]=\"readonly()\"\n      (input)=\"onHourInput($event)\"\n      (blur)=\"onHourBlur()\"\n      maxlength=\"2\"\n      placeholder=\"12\"\n      id=\"frey-timepicker-hour\"\n    />\n    <label class=\"time-picker__label\" for=\"frey-timepicker-hour\">Hora</label>\n  </div>\n  <div class=\"time-picker__separator\">:</div>\n  <div class=\"time-picker__input-group\">\n    <input\n      class=\"time-picker__input\"\n      type=\"text\"\n      [value]=\"minute()\"\n      [disabled]=\"isInputDisabled()\"\n      [readonly]=\"readonly()\"\n      (input)=\"onMinuteInput($event)\"\n      (blur)=\"onMinuteBlur()\"\n      maxlength=\"2\"\n      placeholder=\"00\"\n      id=\"frey-timepicker-minute\"\n    />\n    <label class=\"time-picker__label\" for=\"frey-timepicker-minute\">Minutos</label>\n  </div>\n\n  <button\n    class=\"time-picker__period-button\"\n    [class.time-picker__period-button--active]=\"period() === 'AM'\"\n    [disabled]=\"isInteractionDisabled()\"\n    (click)=\"togglePeriod()\"\n  >\n    AM\n  </button>\n  <button\n    class=\"time-picker__period-button\"\n    [class.time-picker__period-button--active]=\"period() === 'PM'\"\n    [disabled]=\"isInteractionDisabled()\"\n    (click)=\"togglePeriod()\"\n  >\n    PM\n  </button>\n</div>\n" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyTimepickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'frey-timepicker', imports: [], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FreyTimepickerComponent),
                            multi: true,
                        },
                    ], template: "<ng-content select=\"frey-label\"></ng-content>\n<div\n  class=\"time-picker\"\n  [class.time-picker--disabled]=\"isInputDisabled()\"\n  [class.time-picker--readonly]=\"readonly()\"\n>\n  <div class=\"time-picker__input-group\">\n    <input\n      class=\"time-picker__input\"\n      type=\"text\"\n      [value]=\"hour()\"\n      [disabled]=\"isInputDisabled()\"\n      [readonly]=\"readonly()\"\n      (input)=\"onHourInput($event)\"\n      (blur)=\"onHourBlur()\"\n      maxlength=\"2\"\n      placeholder=\"12\"\n      id=\"frey-timepicker-hour\"\n    />\n    <label class=\"time-picker__label\" for=\"frey-timepicker-hour\">Hora</label>\n  </div>\n  <div class=\"time-picker__separator\">:</div>\n  <div class=\"time-picker__input-group\">\n    <input\n      class=\"time-picker__input\"\n      type=\"text\"\n      [value]=\"minute()\"\n      [disabled]=\"isInputDisabled()\"\n      [readonly]=\"readonly()\"\n      (input)=\"onMinuteInput($event)\"\n      (blur)=\"onMinuteBlur()\"\n      maxlength=\"2\"\n      placeholder=\"00\"\n      id=\"frey-timepicker-minute\"\n    />\n    <label class=\"time-picker__label\" for=\"frey-timepicker-minute\">Minutos</label>\n  </div>\n\n  <button\n    class=\"time-picker__period-button\"\n    [class.time-picker__period-button--active]=\"period() === 'AM'\"\n    [disabled]=\"isInteractionDisabled()\"\n    (click)=\"togglePeriod()\"\n  >\n    AM\n  </button>\n  <button\n    class=\"time-picker__period-button\"\n    [class.time-picker__period-button--active]=\"period() === 'PM'\"\n    [disabled]=\"isInteractionDisabled()\"\n    (click)=\"togglePeriod()\"\n  >\n    PM\n  </button>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { initialTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialTime", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], minTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "minTime", required: false }] }], maxTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxTime", required: false }] }], timeChange: [{ type: i0.Output, args: ["timeChange"] }] } });

/**
 * Public API Surface of Freya Table
 */

/**
 * Generated bundle index. Do not edit.
 */

export { FreyTimepickerComponent };
//# sourceMappingURL=freya-timepicker.mjs.map
