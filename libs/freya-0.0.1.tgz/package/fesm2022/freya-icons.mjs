import * as i0 from '@angular/core';
import { InjectionToken, makeEnvironmentProviders, inject, Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

// projects/freya/icons/defaults/default-icons.ts
/**
 * Iconos SVG por defecto de Freya.
 * Estos se usan cuando no hay configuración personalizada.
 */
const DEFAULT_FREY_ICONS = {
    success: {
        type: 'svg',
        viewBox: '0 0 24 24',
        svgContent: `
     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-badge-check-icon lucide-badge-check"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4"/></svg>
    `,
    },
    error: {
        type: 'svg',
        viewBox: '0 0 24 24',
        svgContent: `
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-badge-x-icon lucide-badge-x"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><line x1="15" x2="9" y1="9" y2="15"/><line x1="9" x2="15" y1="9" y2="15"/></svg>
    `,
    },
    warning: {
        type: 'svg',
        viewBox: '0 0 24 24',
        svgContent: `
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-badge-alert-icon lucide-badge-alert"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
    `,
    },
    info: {
        type: 'svg',
        viewBox: '0 0 24 24',
        svgContent: `
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-badge-info-icon lucide-badge-info"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><line x1="12" x2="12" y1="16" y2="12"/><line x1="12" x2="12.01" y1="8" y2="8"/></svg>
    `,
    },
    question: {
        type: 'svg',
        viewBox: '0 0 24 24',
        svgContent: `
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-badge-question-mark-icon lucide-badge-question-mark"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" x2="12.01" y1="17" y2="17"/></svg>
    `,
    },
};

/**
 * Token de inyección para la configuración global de iconos de Freya.
 *
 * @example
 * // En app.config.ts
 * providers: [
 *   {
 *     provide: FREY_ICON_CONFIG,
 *     useValue: {
 *       defaultType: 'font',
 *       defaultFontSet: 'material-icons',
 *       icons: {
 *         success: { type: 'font', fontIcon: 'check_circle' }
 *       }
 *     }
 *   }
 * ]
 */
const FREY_ICON_CONFIG = new InjectionToken('FREY_ICON_CONFIG', {
    providedIn: 'root',
    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    factory: () => ({
        defaultType: 'svg',
        cssPrefix: 'frey-icon',
    }),
});

// projects/freya/icons/providers/frey-icons.provider.ts
/**
 * Configura los iconos de Freya a nivel de aplicación.
 *
 * @example
 * // Opción 1: Usar iconos SVG por defecto (no requiere configuración)
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     // No necesitas agregar nada, usa defaults
 *   ]
 * };
 *
 * @example
 * // Opción 2: Usar Material Icons
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideFreyIcons({
 *       defaultType: 'ligature',
 *       defaultFontSet: 'material-icons',
 *       icons: {
 *         success: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'check_circle' },
 *         error: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'error' },
 *         warning: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'warning' },
 *         info: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'info' },
 *         question: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'help' },
 *       }
 *     })
 *   ]
 * };
 *
 * @example
 * // Opción 3: Usar Font Awesome
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideFreyIcons({
 *       defaultType: 'font',
 *       defaultFontSet: 'fa fa-solid',
 *       icons: {
 *         success: { type: 'font', fontSet: 'fa fa-solid', fontIcon: 'fa-check' },
 *         error: { type: 'font', fontSet: 'fa fa-solid', fontIcon: 'fa-times' },
 *       }
 *     })
 *   ]
 * };
 *
 * @example
 * // Opción 4: Mezclar (SVG custom + fuentes)
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideFreyIcons({
 *       icons: {
 *         success: {
 *           type: 'svg',
 *           svgContent: '<path d="M9 16.17L4.83 12..."/>',
 *           viewBox: '0 0 24 24'
 *         },
 *         error: {
 *           type: 'ligature',
 *           fontSet: 'material-icons',
 *           fontIcon: 'close'
 *         },
 *       }
 *     })
 *   ]
 * };
 */
function provideFreyIcons(config) {
    return makeEnvironmentProviders([
        {
            provide: FREY_ICON_CONFIG,
            useValue: {
                defaultType: 'svg',
                cssPrefix: 'frey-icon',
                ...config,
            },
        },
    ]);
}

/**
 * Servicio Registry para gestión avanzada de iconos.
 *
 * Permite registrar, sobrescribir y resolver iconos dinámicamente.
 *
 * @example
 * ```ts
 * constructor(private iconRegistry: FreyIconRegistry) {
 *   Registrar SVG custom
 *   this.iconRegistry.registerSvgIcon('success', '<svg>...</svg>');
 *
 *   Registrar fuente de iconos
 *   this.iconRegistry.registerFontIcon('error', 'material-icons', 'error_outline');
 *
 *   Cargar desde URL
 *   this.iconRegistry.registerSvgIconFromUrl('custom', '/assets/icon.svg');
 * }
 * ```
 */
class FreyIconRegistry {
    config = inject(FREY_ICON_CONFIG);
    sanitizer = inject(DomSanitizer);
    /**
     * Registro interno de iconos (Runtime)
     * Se sobrescribe en orden: defaults → config → registry
     */
    iconRegistry = new Map();
    constructor() {
        this.initializeDefaults();
    }
    /**
     * Registra un icono SVG desde un string
     */
    registerSvgIcon(name, svgContent, viewBox = '0 0 24 24') {
        this.iconRegistry.set(name, {
            type: 'svg',
            svgContent,
            viewBox,
        });
    }
    /**
     * Registra un icono desde una fuente de iconos (Material Icons, Font Awesome, etc.)
     */
    registerFontIcon(name, fontSet, fontIcon) {
        this.iconRegistry.set(name, {
            type: 'font',
            fontSet,
            fontIcon,
        });
    }
    /**
     * Registra un icono ligature (Material Icons ligatures)
     */
    registerLigatureIcon(name, fontSet, ligature) {
        this.iconRegistry.set(name, {
            type: 'ligature',
            fontSet,
            fontIcon: ligature,
        });
    }
    /**
     * Registra HTML custom
     */
    registerCustomIcon(name, customHtml) {
        this.iconRegistry.set(name, {
            type: 'custom',
            customHtml,
        });
    }
    /**
     * Resuelve la definición de un icono
     * Busca en: registry → config → defaults
     */
    getIconDefinition(name) {
        return this.iconRegistry.get(name) || null;
    }
    /**
     * Genera el HTML sanitizado para renderizar el icono
     */
    getIconHtml(name) {
        const definition = this.getIconDefinition(name);
        if (!definition) {
            return null;
        }
        switch (definition.type) {
            case 'svg':
                return this.sanitizer.bypassSecurityTrustHtml(`<svg viewBox="${definition.viewBox || '0 0 24 24'}" class="${this.config.cssPrefix}">
            ${definition.svgContent}
          </svg>`);
            case 'font':
            case 'ligature':
                return this.sanitizer.bypassSecurityTrustHtml(`<i class="${definition.fontSet} ${definition.cssClass || ''}">
            ${definition.fontIcon}
          </i>`);
            case 'custom':
                return this.sanitizer.bypassSecurityTrustHtml(definition.customHtml || '');
            default:
                return null;
        }
    }
    /**
     * Obtiene las clases CSS para un icono
     */
    getIconClasses(name) {
        const definition = this.getIconDefinition(name);
        if (!definition) {
            return [];
        }
        const classes = [this.config.cssPrefix || 'frey-icon'];
        if (definition.type === 'font' || definition.type === 'ligature') {
            if (definition.fontSet) {
                classes.push(definition.fontSet);
            }
            if (definition.cssClass) {
                classes.push(definition.cssClass);
            }
        }
        return classes;
    }
    /**
     * Verifica si un icono está registrado
     */
    hasIcon(name) {
        return this.iconRegistry.has(name);
    }
    /**
     * Elimina un icono del registro (revierte a default)
     */
    unregisterIcon(name) {
        this.iconRegistry.delete(name);
        // Re-cargar default si existe
        if (DEFAULT_FREY_ICONS[name]) {
            this.iconRegistry.set(name, DEFAULT_FREY_ICONS[name]);
        }
    }
    /**
     * Inicializa el registro con defaults y configuración
     */
    initializeDefaults() {
        // 1. Cargar defaults
        Object.entries(DEFAULT_FREY_ICONS).forEach(([name, definition]) => {
            this.iconRegistry.set(name, definition);
        });
        // 2. Sobrescribir con config global
        if (this.config.icons) {
            Object.entries(this.config.icons).forEach(([name, definition]) => {
                this.iconRegistry.set(name, definition);
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyIconRegistry, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyIconRegistry, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyIconRegistry, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { DEFAULT_FREY_ICONS, FREY_ICON_CONFIG, FreyIconRegistry, provideFreyIcons };
//# sourceMappingURL=freya-icons.mjs.map
