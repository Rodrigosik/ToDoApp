import * as i0 from '@angular/core';
import { inject, ElementRef, EventEmitter, forwardRef, HostListener, Output, Input, Directive } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

var InputValidationRegexEnum;
(function (InputValidationRegexEnum) {
    InputValidationRegexEnum["onlyNumbers"] = "[^0-9]";
    InputValidationRegexEnum["name"] = "[^A-Z\u00C1\u00C9\u00CD\u00D3\u00DAa-z\u00F1\u00E1\u00E9\u00ED\u00F3\u00FA\u00F1\u00D1 ]";
    InputValidationRegexEnum["email"] = "[^A-Za-z0-9-_.@ ]";
    InputValidationRegexEnum["alphanumeric"] = "[^A-Z\u00C1\u00C9\u00CD\u00D3\u00DAa-z\u00F1\u00E1\u00E9\u00ED\u00F3\u00FA\u00F1\u00D1 0-9]";
    InputValidationRegexEnum["default"] = "[^A-Z\u00C1\u00C9\u00CD\u00D3\u00DAa-z\u00F1\u00E1\u00E9\u00ED\u00F3\u00FA\u00F1\u00D10-9., ]";
})(InputValidationRegexEnum || (InputValidationRegexEnum = {}));
class FreyInputValidationDirective {
    freyInputValidation;
    allowSpaces = false;
    isUppercase = false;
    maxAmount = Number.MAX_SAFE_INTEGER;
    freyInputValidationChange;
    element = inject(ElementRef);
    constructor() {
        this.freyInputValidationChange = new EventEmitter();
    }
    writeValue(value) {
        if (value !== null && value !== undefined) {
            this.element.nativeElement.value = value;
        }
        else {
            this.element.nativeElement.value = '';
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.element.nativeElement.disabled = isDisabled;
    }
    handleInputChange() {
        const regex = this.validaRegex();
        let value = this.element.nativeElement.value;
        value = value.replace(regex, '');
        value = this.buildValue(value);
        this.element.nativeElement.value = value;
        // Verificar si el input está vacío y emitir null
        if (!value || value.toString().trim() === '') {
            this.onChange(null);
            this.freyInputValidationChange.emit(null);
            return;
        }
        if (this.isValidInput(value)) {
            this.onChange(value);
            this.freyInputValidationChange.emit(value);
        }
    }
    onBlur() {
        this.onTouched();
    }
    isValidInput(value) {
        // Si está vacío, no es válido para la validación interna
        if (!value && value !== 0) {
            return false;
        }
        if (this.freyInputValidation === 'number' || this.freyInputValidation === 'number:string') {
            const numericValue = Number(value);
            return !isNaN(numericValue) && value.toString() !== '';
        }
        return value.toString().trim() !== '';
    }
    validaRegex() {
        const validationMap = {
            ['number']: 'onlyNumbers',
            ['number:string']: 'onlyNumbers',
            ['name']: 'name',
            ['email']: 'email',
            ['alphanumeric']: 'alphanumeric',
        };
        const regexKey = validationMap[this.freyInputValidation] || 'default';
        return this.getRegexString(InputValidationRegexEnum[regexKey]);
    }
    getRegexString(regexString) {
        return new RegExp(regexString, 'g');
    }
    buildValue(value) {
        if (!this.allowSpaces) {
            value = value.replace(/\s{2,}/g, ' ');
        }
        if (this.isUppercase) {
            value = value.toUpperCase();
        }
        if (this.freyInputValidation === 'number' && value) {
            value = this.convertToSafeInt(value);
        }
        return value;
    }
    convertToSafeInt(numeroStr) {
        const MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER;
        const numero = Number(numeroStr);
        if (isNaN(numero)) {
            return MAX_SAFE_INTEGER;
        }
        if (numero > MAX_SAFE_INTEGER) {
            return MAX_SAFE_INTEGER;
        }
        if (numero > this.maxAmount) {
            return this.maxAmount;
        }
        return Math.floor(numero);
    }
    onChange = () => { };
    onTouched = () => { };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyInputValidationDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: FreyInputValidationDirective, isStandalone: true, selector: "[freyInputValidation]", inputs: { freyInputValidation: "freyInputValidation", allowSpaces: "allowSpaces", isUppercase: "isUppercase", maxAmount: "maxAmount" }, outputs: { freyInputValidationChange: "freyInputValidationChange" }, host: { listeners: { "input": "handleInputChange()", "blur": "onBlur()" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FreyInputValidationDirective),
                multi: true,
            },
        ], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: FreyInputValidationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[freyInputValidation]',
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FreyInputValidationDirective),
                            multi: true,
                        },
                    ],
                }]
        }], ctorParameters: () => [], propDecorators: { freyInputValidation: [{
                type: Input
            }], allowSpaces: [{
                type: Input
            }], isUppercase: [{
                type: Input
            }], maxAmount: [{
                type: Input
            }], freyInputValidationChange: [{
                type: Output
            }], handleInputChange: [{
                type: HostListener,
                args: ['input']
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FreyInputValidationDirective };
//# sourceMappingURL=freya-input-validation.mjs.map
