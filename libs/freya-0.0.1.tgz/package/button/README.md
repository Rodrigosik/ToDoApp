# FreyButton Directive

Directiva standalone para botones que proporciona funcionalidad sin estilos predefinidos.

## 📦 Instalación

```typescript
import { FreyButtonDirective } from 'freya/button';
```

## 🎨 Estilos (Opcionales)

Los estilos son **completamente opcionales**. Freya proporciona estilos por defecto, pero puedes usar los tuyos propios.

### Opción 1: Usar estilos de Freya

Importa los estilos en tu `angular.json`:

```json
{
  "styles": [
    "node_modules/freya/styles/button/button.scss"
  ]
}
```

O en tu archivo `styles.scss`:

```scss
@import 'freya/styles/button/button.scss';
```

### Opción 2: Estilos personalizados

Aplica tus propios estilos a la clase `.frey-button`:

```scss
.frey-button {
  background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  // ... tus estilos
}
```

### Opción 3: Sin estilos

Simplemente no importes nada. El botón usará los estilos nativos del navegador.

## 📝 Uso

### Básico

```html
<button freyButton>Click me</button>
```

### Variantes (Solid, Outline, Ghost)

```html
<!-- Solid (default) -->
<button freyButton color="primary">Primary</button>
<button freyButton color="secondary">Secondary</button>
<button freyButton color="success">Success</button>
<button freyButton color="danger">Danger</button>

<!-- Outline -->
<button freyButton variant="outline" color="primary">Outline Primary</button>
<button freyButton variant="outline" color="danger">Outline Danger</button>

<!-- Ghost -->
<button freyButton variant="ghost">Ghost Button</button>
```

### Tamaños

```html
<button freyButton size="small">Small</button>
<button freyButton size="medium">Medium</button> <!-- Default -->
<button freyButton size="large">Large</button>
```

### Estados

```html
<!-- Deshabilitado -->
<button freyButton [disabled]="true">Disabled</button>

<!-- Loading -->
<button freyButton [loading]="true">Loading...</button>

<!-- Loading deshabilita automáticamente el botón -->
<button freyButton [loading]="isProcessing">
  {{ isProcessing ? 'Processing...' : 'Submit' }}
</button>
```

### Con iconos

```html
<!-- Con icono a la izquierda -->
<button freyButton>
  <svg>...</svg>
  Send Message
</button>

<!-- Solo icono -->
<button freyButton [iconOnly]="true">
  <svg>...</svg>
</button>

<!-- Circular -->
<button freyButton [circular]="true">+</button>
```

### Combinaciones

```html
<!-- Botón grande, outline, success, con icono -->
<button freyButton 
  size="large" 
  variant="outline" 
  color="success">
  <svg>...</svg>
  Save Changes
</button>

<!-- Botón pequeño, danger, circular -->
<button freyButton 
  size="small" 
  [circular]="true" 
  color="danger">
  ✕
</button>
```

## 🔧 API

### Inputs

| Nombre | Tipo | Default | Descripción |
|--------|------|---------|-------------|
| `variant` | `'solid' \| 'outline' \| 'ghost'` | `'solid'` | Variante visual del botón |
| `color` | `'primary' \| 'secondary' \| 'success' \| 'danger'` | `'primary'` | Color del botón |
| `size` | `'small' \| 'medium' \| 'large'` | `'medium'` | Tamaño del botón |
| `loading` | `boolean` | `false` | Muestra estado de carga y deshabilita |
| `disabled` | `boolean` | `false` | Deshabilita el botón |
| `circular` | `boolean` | `false` | Botón circular (ideal para iconos) |
| `iconOnly` | `boolean` | `false` | Botón solo con icono (ajusta padding) |

### Outputs

No tiene outputs. Usa el evento nativo `(click)` de HTML.

```html
<button freyButton (click)="handleClick()">Click me</button>
```

El click no se dispara cuando el botón está `disabled` o en estado `loading`.

## 🎨 Variantes de Estilos

### Solid Buttons (Default)

Botones con fondo sólido de color:

- **Primary**: Amarillo (`#ffd700`)
- **Secondary**: Gris (`#e8e8e8`)
- **Success**: Verde (`#10b981`)
- **Danger**: Rojo (`#ef4444`)

### Outline Buttons

Botones con borde de color y fondo transparente:

```html
<button freyButton variant="outline" color="primary">Outline</button>
```

### Ghost Buttons

Botones sin borde ni fondo (solo hover):

```html
<button freyButton variant="ghost">Ghost</button>
```

## 📐 Tamaños

| Tamaño | Padding | Font Size | Border Radius |
|--------|---------|-----------|---------------|
| Small | `6px 12px` | `12px` | `8px` |
| Medium | `10px 14px` | `14px` | `12px` |
| Large | `14px 24px` | `16px` | `14px` |

## 🔄 Estados

### Disabled

```html
<button freyButton [disabled]="true">Disabled</button>
```

- Opacidad: 50%
- Cursor: `not-allowed`
- No responde a hover

### Loading

```html
<button freyButton [loading]="true">Processing...</button>
```

- Muestra spinner animado a la izquierda
- Automáticamente deshabilitado
- Opacidad: 80%
- Cursor: `wait`

## 💡 Ejemplos Completos

### Formulario de Login

```html
<form (submit)="onLogin()">
  <!-- Botón primario large para acción principal -->
  <button 
    freyButton 
    size="large" 
    color="primary"
    [loading]="isLoggingIn"
    type="submit">
    {{ isLoggingIn ? 'Logging in...' : 'Login' }}
  </button>
  
  <!-- Botón ghost para acción secundaria -->
  <button 
    freyButton 
    variant="ghost"
    type="button"
    (click)="onForgotPassword()">
    Forgot password?
  </button>
</form>
```

### Toolbar con Iconos

```html
<div class="toolbar">
  <!-- Botones circulares para acciones -->
  <button freyButton [circular]="true" color="primary">
    <svg><!-- Agregar icono --></svg>
  </button>
  
  <button freyButton [circular]="true" variant="outline">
    <svg><!-- Editar icono --></svg>
  </button>
  
  <button freyButton [circular]="true" color="danger">
    <svg><!-- Eliminar icono --></svg>
  </button>
  
  <!-- Botón de menú -->
  <button freyButton [iconOnly]="true" variant="ghost">
    <svg><!-- Menú icono --></svg>
  </button>
</div>
```

### Confirmación de Eliminación

```html
<div class="confirmation-dialog">
  <p>¿Estás seguro de que quieres eliminar este elemento?</p>
  
  <div class="actions">
    <button 
      freyButton 
      variant="ghost"
      (click)="onCancel()">
      Cancelar
    </button>
    
    <button 
      freyButton 
      color="danger"
      [loading]="isDeleting"
      (click)="onConfirmDelete()">
      {{ isDeleting ? 'Eliminando...' : 'Eliminar Permanentemente' }}
    </button>
  </div>
</div>
```

## 🎯 Características

- ✅ Standalone (no requiere módulos)
- ✅ Estilos completamente opcionales
- ✅ 4 colores predefinidos (primary, secondary, success, danger)
- ✅ 3 variantes (solid, outline, ghost)
- ✅ 3 tamaños (small, medium, large)
- ✅ Estados: disabled, loading
- ✅ Soporte para iconos
- ✅ Botones circulares
- ✅ Tree-shakeable
- ✅ Accesible
- ✅ TypeScript strict mode
- ✅ Totalmente personalizable
- ✅ Animaciones suaves
- ✅ Responsive

## 📚 Ver en Storybook

Consulta las stories de Storybook para ver ejemplos interactivos:

```bash
npm run storybook
```

Navega a **Freya > Button** para ver todas las variantes y ejemplos.
