import * as i0 from '@angular/core';

/**
 * Tipo de variante del botón
 */
type ButtonVariant = 'solid' | 'outline' | 'ghost';
/**
 * Color del botón
 */
type ButtonColor = 'primary' | 'secondary' | 'success' | 'danger';
/**
 * Tamaño del botón
 */
type ButtonSize = 'small' | 'medium' | 'large';
/**
 * Directiva para botones de Freya UI.
 *
 * Esta directiva proporciona funcionalidad de botón sin estilos predefinidos.
 * Los estilos son completamente opcionales y se pueden importar:
 *
 * @example
 * ```typescript
 * // En tu angular.json o styles.scss (opcional):
 * import 'freya/styles/button/button.scss';
 * ```
 *
 * @example
 * ```html
 * <!-- Botón sólido primario -->
 * <button freyButton>Click me</button>
 *
 * <!-- Botón outline danger -->
 * <button freyButton variant="outline" color="danger">Delete</button>
 *
 * <!-- Botón grande con loading -->
 * <button freyButton size="large" [loading]="true">Saving...</button>
 *
 * <!-- Botón circular -->
 * <button freyButton [circular]="true">+</button>
 * ```
 */
declare class FreyButtonDirective {
    /**
     * Variante del botón: solid, outline, ghost
     * @default 'solid'
     */
    variant: ButtonVariant;
    /**
     * Color del botón: primary, secondary, success, danger
     * @default 'primary'
     */
    color: ButtonColor;
    /**
     * Tamaño del botón: small, medium, large
     * @default 'medium'
     */
    size: ButtonSize;
    /**
     * Si true, muestra el estado de carga
     * @default false
     */
    loading: boolean;
    /**
     * Si true, el botón está deshabilitado
     * @default false
     */
    disabled: boolean;
    /**
     * Si true, el botón es circular (para iconos)
     * @default false
     */
    circular: boolean;
    /**
     * Si true, el botón solo muestra icono sin padding extra
     * @default false
     */
    iconOnly: boolean;
    /**
     * Clases computadas para el host
     */
    get hostClasses(): string;
    /**
     * Atributo disabled del botón
     */
    get isDisabled(): true | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FreyButtonDirective, "[freyButton]", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "circular": { "alias": "circular"; "required": false; }; "iconOnly": { "alias": "iconOnly"; "required": false; }; }, {}, never, never, true, never>;
}

export { FreyButtonDirective };
export type { ButtonColor, ButtonSize, ButtonVariant };
