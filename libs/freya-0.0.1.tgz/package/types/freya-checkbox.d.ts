import * as _angular_core from '@angular/core';
import { OnChanges, EventEmitter, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

declare class FreyCheckboxComponent implements ControlValueAccessor, OnChanges {
    disabled: boolean;
    readonly: boolean;
    value: boolean;
    changeSelection: EventEmitter<boolean>;
    labelContent$$: _angular_core.Signal<ElementRef<any>>;
    hasLabelContent$$: _angular_core.Signal<boolean>;
    iconContent$$: _angular_core.Signal<ElementRef<any>>;
    hasIconContent$$: _angular_core.Signal<boolean>;
    checked$$: _angular_core.WritableSignal<boolean>;
    onChange: any;
    onTouched: any;
    ngOnChanges(): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    writeValue(value: boolean): void;
    onModelChange(value: boolean): void;
    setDisabledState?(disabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyCheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyCheckboxComponent, "frey-checkbox", never, { "disabled": { "alias": "disabled"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "changeSelection": "changeSelection"; }, never, ["[icon]", "*"], true, never>;
}

export { FreyCheckboxComponent };
