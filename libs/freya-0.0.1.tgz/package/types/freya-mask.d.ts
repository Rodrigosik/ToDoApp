import { ControlValueAccessor } from '@angular/forms';
import * as i0 from '@angular/core';

declare class FreyMaskDirective implements ControlValueAccessor {
    customMask: string;
    private readonly allowedCharacters;
    private readonly elementRef;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onInput(): void;
    onBlur(): void;
    private applyMaskToCurrentValue;
    private applyMask;
    private buildControlValue;
    private onChange;
    private onTouched;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyMaskDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FreyMaskDirective, "[freyMask]", never, { "customMask": { "alias": "freyMask"; "required": false; }; }, {}, never, never, true, never>;
}

export { FreyMaskDirective };
