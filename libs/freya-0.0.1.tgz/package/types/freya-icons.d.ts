import * as i0 from '@angular/core';
import { EnvironmentProviders, InjectionToken } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';

/**
 * Tipo de renderizado de iconos soportados
 */
type IconType = 'svg' | 'font' | 'ligature' | 'custom';
/**
 * Nombres de iconos predefinidos de Freya
 */
type FreyIconName = 'success' | 'error' | 'warning' | 'info' | 'question' | 'close' | 'check' | 'arrow-left' | 'arrow-right';
/**
 * Configuración de un icono individual
 */
interface FreyIconDefinition {
    /** Tipo de icono */
    type: IconType;
    /** Contenido SVG (para type='svg') */
    svgContent?: string;
    /** Nombre de la clase CSS (para type='font' o 'ligature') */
    fontIcon?: string;
    /** Clase de la fuente (ej: 'material-icons') */
    fontSet?: string;
    /** Contenido HTML custom (para type='custom') */
    customHtml?: string;
    /** ViewBox del SVG (opcional, default: '0 0 24 24') */
    viewBox?: string;
    /** Clases CSS adicionales */
    cssClass?: string;
}
/**
 * Mapa de iconos personalizados
 */
type FreyIconMap = Partial<Record<FreyIconName, FreyIconDefinition>>;
/**
 * Configuración global de iconos de Freya
 */
interface FreyIconConfig {
    /**
     * Tipo de iconos por defecto para toda la librería
     * @default 'svg'
     */
    defaultType?: IconType;
    /**
     * Fuente de iconos por defecto (ej: 'material-icons', 'fa', 'pi')
     * Solo aplica si defaultType es 'font' o 'ligature'
     */
    defaultFontSet?: string;
    /**
     * Mapa de iconos personalizados que sobrescribe los defaults
     */
    icons?: FreyIconMap;
    /**
     * Prefijo para clases CSS de iconos
     * @default 'frey-icon'
     */
    cssPrefix?: string;
}

/**
 * Iconos SVG por defecto de Freya.
 * Estos se usan cuando no hay configuración personalizada.
 */
declare const DEFAULT_FREY_ICONS: FreyIconMap;

/**
 * Configura los iconos de Freya a nivel de aplicación.
 *
 * @example
 * // Opción 1: Usar iconos SVG por defecto (no requiere configuración)
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     // No necesitas agregar nada, usa defaults
 *   ]
 * };
 *
 * @example
 * // Opción 2: Usar Material Icons
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideFreyIcons({
 *       defaultType: 'ligature',
 *       defaultFontSet: 'material-icons',
 *       icons: {
 *         success: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'check_circle' },
 *         error: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'error' },
 *         warning: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'warning' },
 *         info: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'info' },
 *         question: { type: 'ligature', fontSet: 'material-icons', fontIcon: 'help' },
 *       }
 *     })
 *   ]
 * };
 *
 * @example
 * // Opción 3: Usar Font Awesome
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideFreyIcons({
 *       defaultType: 'font',
 *       defaultFontSet: 'fa fa-solid',
 *       icons: {
 *         success: { type: 'font', fontSet: 'fa fa-solid', fontIcon: 'fa-check' },
 *         error: { type: 'font', fontSet: 'fa fa-solid', fontIcon: 'fa-times' },
 *       }
 *     })
 *   ]
 * };
 *
 * @example
 * // Opción 4: Mezclar (SVG custom + fuentes)
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideFreyIcons({
 *       icons: {
 *         success: {
 *           type: 'svg',
 *           svgContent: '<path d="M9 16.17L4.83 12..."/>',
 *           viewBox: '0 0 24 24'
 *         },
 *         error: {
 *           type: 'ligature',
 *           fontSet: 'material-icons',
 *           fontIcon: 'close'
 *         },
 *       }
 *     })
 *   ]
 * };
 */
declare function provideFreyIcons(config: FreyIconConfig): EnvironmentProviders;

/**
 * Servicio Registry para gestión avanzada de iconos.
 *
 * Permite registrar, sobrescribir y resolver iconos dinámicamente.
 *
 * @example
 * ```ts
 * constructor(private iconRegistry: FreyIconRegistry) {
 *   Registrar SVG custom
 *   this.iconRegistry.registerSvgIcon('success', '<svg>...</svg>');
 *
 *   Registrar fuente de iconos
 *   this.iconRegistry.registerFontIcon('error', 'material-icons', 'error_outline');
 *
 *   Cargar desde URL
 *   this.iconRegistry.registerSvgIconFromUrl('custom', '/assets/icon.svg');
 * }
 * ```
 */
declare class FreyIconRegistry {
    private readonly config;
    private readonly sanitizer;
    /**
     * Registro interno de iconos (Runtime)
     * Se sobrescribe en orden: defaults → config → registry
     */
    private iconRegistry;
    constructor();
    /**
     * Registra un icono SVG desde un string
     */
    registerSvgIcon(name: FreyIconName, svgContent: string, viewBox?: string): void;
    /**
     * Registra un icono desde una fuente de iconos (Material Icons, Font Awesome, etc.)
     */
    registerFontIcon(name: FreyIconName, fontSet: string, fontIcon: string): void;
    /**
     * Registra un icono ligature (Material Icons ligatures)
     */
    registerLigatureIcon(name: FreyIconName, fontSet: string, ligature: string): void;
    /**
     * Registra HTML custom
     */
    registerCustomIcon(name: FreyIconName, customHtml: string): void;
    /**
     * Resuelve la definición de un icono
     * Busca en: registry → config → defaults
     */
    getIconDefinition(name: FreyIconName): FreyIconDefinition | null;
    /**
     * Genera el HTML sanitizado para renderizar el icono
     */
    getIconHtml(name: FreyIconName): SafeHtml | null;
    /**
     * Obtiene las clases CSS para un icono
     */
    getIconClasses(name: FreyIconName): string[];
    /**
     * Verifica si un icono está registrado
     */
    hasIcon(name: FreyIconName): boolean;
    /**
     * Elimina un icono del registro (revierte a default)
     */
    unregisterIcon(name: FreyIconName): void;
    /**
     * Inicializa el registro con defaults y configuración
     */
    private initializeDefaults;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyIconRegistry, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FreyIconRegistry>;
}

/**
 * Token de inyección para la configuración global de iconos de Freya.
 *
 * @example
 * // En app.config.ts
 * providers: [
 *   {
 *     provide: FREY_ICON_CONFIG,
 *     useValue: {
 *       defaultType: 'font',
 *       defaultFontSet: 'material-icons',
 *       icons: {
 *         success: { type: 'font', fontIcon: 'check_circle' }
 *       }
 *     }
 *   }
 * ]
 */
declare const FREY_ICON_CONFIG: InjectionToken<FreyIconConfig>;

export { DEFAULT_FREY_ICONS, FREY_ICON_CONFIG, FreyIconRegistry, provideFreyIcons };
export type { FreyIconConfig, FreyIconDefinition, FreyIconMap, FreyIconName, IconType };
