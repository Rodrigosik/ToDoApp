import * as freya_table from 'freya/table';
import * as _angular_core from '@angular/core';
import { TemplateRef, AfterContentInit } from '@angular/core';
import * as i6 from '@angular/common';

declare class FreyCellDefDirective {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyCellDefDirective, "[freyCellDef]", never, {}, {}, never, never, false, never>;
}

declare class FreyColumnSortDirective implements AfterContentInit {
    freyColumnSort: _angular_core.InputSignal<string>;
    sortStatus: _angular_core.OutputEmitterRef<boolean>;
    private isArrowUp;
    private readonly elementRef;
    private readonly renderer2;
    ngAfterContentInit(): void;
    private getArrowText;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyColumnSortDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyColumnSortDirective, "[freyColumnSort]", never, { "freyColumnSort": { "alias": "freyColumnSort"; "required": false; "isSignal": true; }; }, { "sortStatus": "sortStatus"; }, never, never, false, never>;
}

declare class FreyHeaderCellDefDirective {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyHeaderCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyHeaderCellDefDirective, "[freyHeaderCellDef]", never, {}, {}, never, never, false, never>;
}

declare class FreyColumnDefDirective {
    columnName: _angular_core.InputSignal<string>;
    headerCellDef: _angular_core.Signal<FreyHeaderCellDefDirective>;
    cellDef: _angular_core.Signal<FreyCellDefDirective>;
    sort: _angular_core.Signal<FreyColumnSortDirective>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyColumnDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FreyColumnDefDirective, "[freyColumnDef]", never, { "columnName": { "alias": "freyColumnDef"; "required": false; "isSignal": true; }; }, {}, ["headerCellDef", "cellDef", "sort"], never, false, never>;
}

interface ClickRowModel {
    name: string;
    data: any;
    rowIndex: number;
}
declare class FreyTableComponent {
    columnDefs: _angular_core.Signal<readonly FreyColumnDefDirective[]>;
    dataSource: _angular_core.ModelSignal<any[]>;
    searchTerm: _angular_core.ModelSignal<string>;
    itemsPerPage: _angular_core.ModelSignal<number>;
    currentPage: _angular_core.ModelSignal<number>;
    selectable: _angular_core.ModelSignal<boolean>;
    searchResults: _angular_core.OutputEmitterRef<number>;
    clickRow: _angular_core.OutputEmitterRef<ClickRowModel>;
    columns: _angular_core.Signal<{
        name: string;
        headerCellDef: freya_table.FreyHeaderCellDefDirective;
        cellDef: freya_table.FreyCellDefDirective;
    }[]>;
    filteredDataBySearch: _angular_core.Signal<any[]>;
    paginatedData: _angular_core.Signal<any[]>;
    selectedRowIndex: _angular_core.WritableSignal<number>;
    selectedRow: _angular_core.WritableSignal<any>;
    private sortState;
    constructor();
    selectRow(columnName: string, row: any, index: number): void;
    isRowSelected(row: any): boolean;
    private onSort;
    private compareValues;
    private compareNumeric;
    private compareString;
    private isNumeric;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyTableComponent, "frey-table", never, { "dataSource": { "alias": "dataSource"; "required": false; "isSignal": true; }; "searchTerm": { "alias": "searchTerm"; "required": false; "isSignal": true; }; "itemsPerPage": { "alias": "itemsPerPage"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; }, { "dataSource": "dataSourceChange"; "searchTerm": "searchTermChange"; "itemsPerPage": "itemsPerPageChange"; "currentPage": "currentPageChange"; "selectable": "selectableChange"; "searchResults": "searchResults"; "clickRow": "clickRow"; }, ["columnDefs"], never, false, never>;
}

declare class FreyTableModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyTableModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<FreyTableModule, [typeof FreyTableComponent, typeof FreyCellDefDirective, typeof FreyColumnDefDirective, typeof FreyColumnSortDirective, typeof FreyHeaderCellDefDirective], [typeof i6.NgTemplateOutlet], [typeof FreyTableComponent, typeof FreyCellDefDirective, typeof FreyColumnDefDirective, typeof FreyColumnSortDirective, typeof FreyHeaderCellDefDirective]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<FreyTableModule>;
}

export { FreyCellDefDirective, FreyColumnDefDirective, FreyColumnSortDirective, FreyHeaderCellDefDirective, FreyTableComponent, FreyTableModule };
