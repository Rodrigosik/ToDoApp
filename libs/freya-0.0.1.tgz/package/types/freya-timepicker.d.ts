import * as _angular_core from '@angular/core';
import { FreyControlValueAccessor } from 'freya/class';

declare class FreyTimepickerComponent extends FreyControlValueAccessor {
    initialTime: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    minTime: _angular_core.InputSignal<string>;
    maxTime: _angular_core.InputSignal<string>;
    timeChange: _angular_core.OutputEmitterRef<string>;
    hour: _angular_core.WritableSignal<string>;
    minute: _angular_core.WritableSignal<string>;
    period: _angular_core.WritableSignal<"AM" | "PM">;
    formControlDisabled: _angular_core.WritableSignal<boolean>;
    isInteractionDisabled: _angular_core.Signal<boolean>;
    isInputDisabled: _angular_core.Signal<boolean>;
    currentTime: _angular_core.Signal<string>;
    constructor();
    writeValue(value: string | null): void;
    setDisabledState(isDisabled: boolean): void;
    onHourInput(event: Event): void;
    onMinuteInput(event: Event): void;
    onHourBlur(): void;
    onMinuteBlur(): void;
    togglePeriod(): void;
    private validateTimeRange;
    private getTimeInMinutes;
    private getTimeInMinutesFromString;
    private sanitizeAndValidateHour;
    private sanitizeAndValidateMinute;
    private formatHour;
    private formatMinute;
    private convertTo24Hour;
    private setTimeFromString;
    private resetToDefault;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyTimepickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyTimepickerComponent, "frey-timepicker", never, { "initialTime": { "alias": "initialTime"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "minTime": { "alias": "minTime"; "required": false; "isSignal": true; }; "maxTime": { "alias": "maxTime"; "required": false; "isSignal": true; }; }, { "timeChange": "timeChange"; }, never, ["frey-label"], true, never>;
}

export { FreyTimepickerComponent };
