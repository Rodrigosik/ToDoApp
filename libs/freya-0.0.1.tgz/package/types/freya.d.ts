/**
 * Versión de Freya UI Library
 */
declare const FREYA_VERSION = "0.0.1";

export { FREYA_VERSION };
