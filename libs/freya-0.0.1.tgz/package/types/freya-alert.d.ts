import * as i0 from '@angular/core';
import { TemplateRef, AfterViewInit, ElementRef, EventEmitter } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import * as i2 from '@angular/common';
import * as i3 from 'freya/button';
import { Observable } from 'rxjs';

type TypeHeader = 'success' | 'error' | 'warning' | 'info' | 'question' | 'none';
declare class FreyAlertModel {
    showConfirmButton: boolean;
    textConfirmButton: string;
    showCancelButton: boolean;
    textCancelButton: string;
    title: string;
    description: string;
    template: TemplateRef<unknown>;
    innerHTML: string;
    zIndex: number;
    typeHeader: TypeHeader;
    colorButtonConfirm: string;
}

declare class AlertComponent implements AfterViewInit {
    confirmButton: ElementRef;
    cancelButton: ElementRef;
    closeMeEvent: EventEmitter<any>;
    confirmEvent: EventEmitter<any>;
    data: FreyAlertModel;
    private readonly renderer2;
    private readonly elementRef;
    private readonly sanitizer;
    private readonly iconRegistry;
    ngAfterViewInit(): void;
    closeMe(): void;
    confirm(): void;
    innerHtmlSanitized(): SafeHtml;
    getIconHtml(iconName: 'success' | 'error' | 'warning' | 'info' | 'question'): SafeHtml | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "frey-alert", never, {}, { "closeMeEvent": "closeMeEvent"; "confirmEvent": "confirmEvent"; }, never, never, false, never>;
}

declare class FreyAlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyAlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FreyAlertModule, [typeof AlertComponent], [typeof i2.NgStyle, typeof i2.NgTemplateOutlet, typeof i3.FreyButtonDirective], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FreyAlertModule>;
}

declare class FreyAlertService {
    private totalModals;
    private currentAlert;
    private readonly renderer2;
    private readonly applicationRef;
    private readonly rendererFactory;
    constructor();
    openAlert(config: FreyAlertModel): Observable<boolean>;
    closeCurrentAlert(): void;
    private buildModal;
    private buildEventsToModal;
    private closeModal;
    static ɵfac: i0.ɵɵFactoryDeclaration<FreyAlertService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FreyAlertService>;
}

export { FreyAlertModel, FreyAlertModule, FreyAlertService };
