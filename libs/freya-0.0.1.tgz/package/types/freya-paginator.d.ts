import * as _angular_core from '@angular/core';

/**
 * Componente Paginador para Freya UI.
 *
 * Este componente proporciona controles de paginación para navegar a través de una colección de elementos.
 * Permite al usuario ver el número total de elementos, el número de elementos por página,
 * y navegar entre páginas utilizando botones de "anterior", "siguiente" y números de página.
 *
 * Los estilos son completamente opcionales.
 * Para usar los estilos por defecto:
 * @import 'freya/styles/paginator/paginator.scss';
 *
 * @example
 * ```html
 * <frey-paginator
 *   [totalItems]="100"
 *   [itemsPerPage]="10"
 *   [currentPage]="1"
 *   (pageChange)="onPageChange($event)"
 *   (itemsPerPageChange)="onItemsPerPageChange($event)"
 * ></frey-paginator>
 * ```
 */
declare class FreyPaginatorComponent {
    labelItemsPerPage: _angular_core.InputSignal<string>;
    labelPrevious: _angular_core.InputSignal<string>;
    labelNext: _angular_core.InputSignal<string>;
    labelTotal: _angular_core.InputSignal<string>;
    labelItems: _angular_core.InputSignal<string>;
    /**
     * El número total de elementos en la colección.
     */
    totalItems: _angular_core.InputSignal<number>;
    /**
     * El número de elementos a mostrar por página.
     * Por defecto es 10.
     */
    itemsPerPage: _angular_core.InputSignal<number>;
    /**
     * La página actual seleccionada.
     * Por defecto es 1.
     */
    currentPage: _angular_core.InputSignal<number>;
    /**
     * Evento emitido cuando la página cambia.
     * Emite el nuevo número de página.
     */
    pageChange: _angular_core.OutputEmitterRef<number>;
    /**
     * Evento emitido cuando cambia el número de elementos por página.
     * Emite el nuevo valor de elementos por página.
     */
    itemsPerPageChange: _angular_core.OutputEmitterRef<number>;
    /** Señal interna para el estado mutable de currentPage */
    _currentPage: _angular_core.WritableSignal<number>;
    /** Señal interna para el estado mutable de itemsPerPage */
    _itemsPerPage: _angular_core.WritableSignal<number>;
    /** El número total de páginas calculadas. */
    totalPages: _angular_core.Signal<number>;
    /** Array de números de página visibles en los controles. */
    visiblePages: _angular_core.Signal<(number | "...")[]>;
    constructor();
    /**
     * Navega a la página especificada.
     * @param page El número de página al que navegar.
     */
    goToPage(page: number): void;
    /**
     * Navega a la página anterior.
     */
    prevPage(): void;
    /**
     * Navega a la página siguiente.
     */
    nextPage(): void;
    /**
     * Actualiza el número de elementos por página basado en la entrada del usuario.
     * @param value El nuevo valor de elementos por página.
     */
    updateItemsPerPage(value: string): void;
    /**
     * Genera un array de números de página para mostrar en los controles.
     * @param currentPage La página actual.
     * @param totalPages El número total de páginas.
     * @returns Un array de números de página visibles.
     */
    private generateVisiblePages;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FreyPaginatorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FreyPaginatorComponent, "frey-paginator", never, { "labelItemsPerPage": { "alias": "labelItemsPerPage"; "required": false; "isSignal": true; }; "labelPrevious": { "alias": "labelPrevious"; "required": false; "isSignal": true; }; "labelNext": { "alias": "labelNext"; "required": false; "isSignal": true; }; "labelTotal": { "alias": "labelTotal"; "required": false; "isSignal": true; }; "labelItems": { "alias": "labelItems"; "required": false; "isSignal": true; }; "totalItems": { "alias": "totalItems"; "required": true; "isSignal": true; }; "itemsPerPage": { "alias": "itemsPerPage"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; }, { "pageChange": "pageChange"; "itemsPerPageChange": "itemsPerPageChange"; }, never, never, true, never>;
}

export { FreyPaginatorComponent };
